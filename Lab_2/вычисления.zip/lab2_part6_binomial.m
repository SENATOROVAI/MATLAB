%% Лабораторная работа 2
% Биномиальная настройка

clear; clc; close all;

T1_cases = [1 0.5];

for k = 1:length(T1_cases)

    T1 = T1_cases(k);
    Kp = 1/(4*T1);

    fprintf('\n--------------------------\n');
    fprintf('T1 = %.2f\n',T1);
    fprintf('Kp = %.4f\n',Kp);

    Wo = tf(1,[T1 1 0]);
    Wcl = feedback(Kp*Wo,1);

    t = 0:0.01:20;
    [y,t] = step(Wcl,t);

    figure;
    plot(t,y,'LineWidth',2)
    grid on
    title(['Биномиальная настройка, T1 = ',num2str(T1)])
    xlabel('t')
    ylabel('y(t)')

    info = stepinfo(Wcl);

    fprintf('Время регулирования = %.4f\n',info.SettlingTime);
    fprintf('Перерегулирование = %.2f %%\n',info.Overshoot);

end