%% Лабораторная работа 2
% Оптимум по модулю (ε = 0)

clear; clc; close all;

T0 = 1;
Tzap = 0.4*T0;

T1_cases = [1 0.5];

for k = 1:length(T1_cases)

    T1 = T1_cases(k);
    Tmu = T1 + Tzap;
    Kp = 1/Tmu;

    fprintf('\n--------------------------\n');
    fprintf('T1 = %.2f\n',T1);
    fprintf('Tmu = %.4f\n',Tmu);
    fprintf('Kp = %.4f\n',Kp);

    Wo = tf(1,[T1 1 0]);
    Wfb = tf(1,[Tzap 1]);

    Wcl = feedback(Kp*Wo,Wfb);

    t = 0:0.01:20;
    [y,t] = step(Wcl,t);

    figure;
    plot(t,y,'LineWidth',2)
    grid on
    title(['Оптимум по модулю, T1 = ',num2str(T1)])
    xlabel('t')
    ylabel('y(t)')

    info = stepinfo(Wcl);

    fprintf('Время регулирования = %.4f\n',info.SettlingTime);
    fprintf('Перерегулирование = %.2f %%\n',info.Overshoot);

end