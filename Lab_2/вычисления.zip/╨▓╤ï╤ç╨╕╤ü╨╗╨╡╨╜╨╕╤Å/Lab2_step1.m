%% Очистка
close all;
bdclose all;
clear;

model = 'lab2_regulators_eps0';
new_system(model);
open_system(model);

%% Параметры
Kp = 20;
T0 = 0.05;

%% Добавление блоков

% Ramp
add_block('simulink/Sources/Ramp', [model '/Ramp'], ...
    'Position', [50 100 80 130]);

% Аналоговый Gain
add_block('simulink/Math Operations/Gain', [model '/Gain_Analog'], ...
    'Gain', num2str(Kp), ...
    'Position', [200 70 260 110]);

% Zero-Order Hold
add_block('simulink/Discrete/Zero-Order Hold', [model '/ZOH'], ...
    'SampleTime', num2str(T0), ...
    'Position', [200 140 260 180]);

% Цифровой Gain
add_block('simulink/Math Operations/Gain', [model '/Gain_Digital'], ...
    'Gain', num2str(Kp), ...
    'Position', [350 140 410 180]);

% Mux (чтобы вывести два сигнала в Scope)
add_block('simulink/Signal Routing/Mux', [model '/Mux'], ...
    'Inputs', '2', ...
    'Position', [500 90 520 170]);

% Scope
add_block('simulink/Sinks/Scope', [model '/Scope'], ...
    'Position', [600 90 650 170]);

%% Соединение блоков

% Ramp → Gain (аналог)
add_line(model, 'Ramp/1', 'Gain_Analog/1');

% Ramp → ZOH
add_line(model, 'Ramp/1', 'ZOH/1');

% ZOH → Gain (цифровой)
add_line(model, 'ZOH/1', 'Gain_Digital/1');

% Выходы в Mux
add_line(model, 'Gain_Analog/1', 'Mux/1');
add_line(model, 'Gain_Digital/1', 'Mux/2');

% Mux → Scope
add_line(model, 'Mux/1', 'Scope/1');

%% Время моделирования
set_param(model, 'StopTime', '1');

%% Запуск
sim(model);

%% Открыть Scope
open_system([model '/Scope']);