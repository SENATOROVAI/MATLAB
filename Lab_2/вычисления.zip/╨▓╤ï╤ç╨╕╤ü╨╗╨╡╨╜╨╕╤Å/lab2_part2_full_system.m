%% Лабораторная работа 2
% Полная система (метод переоборудования)

clear; clc; close all;

%% 1. Параметры
T1 = 0.05;     % по ТЗ
Tmu = 0.05;    % оптимум по модулю
Kp = 1/Tmu;    % = 20
T0_values = [0.005 0.05];

fprintf('Kp = %.2f\n',Kp)

%% 2. Объект
Wo = tf(1,[T1 1 0]);
%% 3. Аналоговая система
Wcl_analog = feedback(Kp*Wo,1);

t = 0:0.001:1;
[y_analog,t_analog] = step(Wcl_analog,t);

info_analog = stepinfo(Wcl_analog);

fprintf('\nАналоговая система:\n')
fprintf('Время регулирования = %.4f\n',info_analog.SettlingTime)
fprintf('Перерегулирование = %.2f %%\n',info_analog.Overshoot)

figure;
plot(t_analog,y_analog,'LineWidth',2)
grid on
title('Аналоговая система')
xlabel('t')
ylabel('y(t)')

%% 4. Цифровые системы

for i = 1:length(T0_values)

    T0 = T0_values(i);
    
    Wo_d = c2d(Wo,T0,'zoh');
    Wcl_d = feedback(Kp*Wo_d,1);
    
    t_d = 0:T0:1;
    [y_d,t_d] = step(Wcl_d,t_d);
    
    info_d = stepinfo(Wcl_d);
    
    fprintf('\nЦифровая система, T0 = %.3f:\n',T0)
    fprintf('Время регулирования = %.4f\n',info_d.SettlingTime)
    fprintf('Перерегулирование = %.2f %%\n',info_d.Overshoot)
    
    figure;
    stairs(t_d,y_d,'LineWidth',2)
    grid on
    title(['Цифровая система, T0 = ',num2str(T0)])
    xlabel('t')
    ylabel('y(t)')

end