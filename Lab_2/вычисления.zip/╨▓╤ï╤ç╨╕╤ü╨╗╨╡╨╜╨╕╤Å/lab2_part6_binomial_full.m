%% Лабораторная работа №2
% Пункт 5 – Биномиальная настройка (полный повтор пп.2–4)

clear; clc; close all;

Tmu1 = 0.05;
T1_cases = [1 0.5];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ТАБЛИЦА 1 – Влияние периода дискретности
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('==========================================')
disp('ТАБЛИЦА 1 – Влияние периода дискретности')
disp('==========================================')

for T1 = T1_cases
    
    Kp = 1/(4*T1);
    Wo = tf(1,[T1 1 0]);
    
    T0_cases = [0.1*Tmu1 Tmu1];
    
    for T0 = T0_cases
        
        Wd = c2d(Kp*Wo,T0,'zoh');
        Wcl_d = feedback(Wd,1);
        
        info = stepinfo(Wcl_d);
        
        fprintf('\nT1 = %.2f   T0 = %.4f\n',T1,T0);
        fprintf('tтр = %.4f\n',info.SettlingTime);
        fprintf('Δy = %.2f %%\n',info.Overshoot);
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ТАБЛИЦА 2 – Поиск Tзап (минимум функционала F)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('==========================================')
disp('ТАБЛИЦА 2 – Поиск Tзап')
disp('==========================================')

T1 = 1;
Kp = 1/(4*T1);
Wo = tf(1,[T1 1 0]);

T0 = Tmu1;

Wd = c2d(Kp*Wo,T0,'zoh');
Wcl_d = feedback(Wd,1);

t = 0:T0:20;                 % шаг = T0 (ВАЖНО)
[y_d,t] = step(Wcl_d,t);

Tzap_cases = [0.1*T0 0.4*T0 0.9*T0];

for Tzap = Tzap_cases
    
    Wzap = tf(1,[Tzap 1]);
    W_equiv = feedback(Kp*Wo*Wzap,1);
    
    y_e = step(W_equiv,t);   % тот же вектор времени
    
    F = trapz(t,abs(y_d - y_e));
    
    fprintf('\nTзап = %.4f   F = %.6f\n',Tzap,F);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ТАБЛИЦА 3 – ε = 0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('==========================================')
disp('ТАБЛИЦА 3 – ε = 0')
disp('==========================================')

Tzap = 0.4*T0;  % обычно даёт минимум F

for T1 = T1_cases
    
    Kp = 1/(4*T1);
    Wo = tf(1,[T1 1 0]);
    Wzap = tf(1,[Tzap 1]);
    
    Wcl = feedback(Kp*Wo*Wzap,1);
    
    info = stepinfo(Wcl);
    Tmu = T1 + Tzap;
    
    fprintf('\nT1 = %.2f\n',T1);
    fprintf('Tμ = %.4f\n',Tmu);
    fprintf('tp1 = %.4f\n',info.SettlingTime);
    fprintf('Δy = %.2f %%\n',info.Overshoot);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ТАБЛИЦА 4 – ε = T0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('==========================================')
disp('ТАБЛИЦА 4 – ε = T0')
disp('==========================================')

for T1 = T1_cases
    
    Kp = 1/(4*T1);
    Wo = tf(1,[T1 1 0]);
    Wzap = tf(1,[Tzap 1]);
    
    Delay = tf(1,1,'InputDelay',T0);
    
    Wcl = feedback(Kp*Wo*Wzap*Delay,1);
    
    info = stepinfo(Wcl);
    Tmu = T1 + Tzap + T0;
    
    fprintf('\nT1 = %.2f\n',T1);
    fprintf('Tμ = %.4f\n',Tmu);
    fprintf('tp1 = %.4f\n',info.SettlingTime);
    fprintf('Δy = %.2f %%\n',info.Overshoot);
    
end