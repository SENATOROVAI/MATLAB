%% Цифровая система (ε = 0)

clear; clc; close all;

T1 = 0.05;
Kp = 1/T1;

Wo = tf(1,[T1 1 0]);

T0_values = [0.005 0.05];

for k = 1:length(T0_values)

    T0 = T0_values(k);

    % Дискретизация объекта
    Wo_d = c2d(Wo,T0,'zoh');

    % Дискретный П-регулятор
    Wreg_d = Kp;

    % Замкнутая цифровая система
    Wcl_d = feedback(Wreg_d*Wo_d,1);

    t = 0:T0:1;
    [y,t] = step(Wcl_d,t);

    figure;
    stairs(t,y,'LineWidth',2)
    grid on
    title(['Цифровая система, T0 = ',num2str(T0)])
    xlabel('t, c')
    ylabel('y(t)')

    info = stepinfo(Wcl_d);

    fprintf('\nT0 = %.4f\n',T0)
    fprintf('Время регулирования = %.4f c\n',info.SettlingTime)
    fprintf('Перерегулирование = %.2f %%\n',info.Overshoot)

end