%% Лабораторная работа 2
% Эквивалентная модель цифровой системы
% ε = 0
% Режим моделирования: T0 = T1 = 1

clear; clc; close all;

%% 1. Исходные данные
T1 = 1;          % по ТЗ
T0 = 1;          % по ТЗ
Kp = 1/T1;       % оптимум по модулю

fprintf('Исходные параметры:\n');
fprintf('T1 = %.2f\n',T1)
fprintf('T0 = %.2f\n',T0)
fprintf('Kp = %.2f\n',Kp)

%% 2. Цифровая система (через дискретизацию)
Wo = tf(1,[T1 1 0]);

Wo_d = c2d(Wo,T0,'zoh');
Wcl_digital = feedback(Kp*Wo_d,1);

t = 0:T0:20;
[y_digital,t_d] = step(Wcl_digital,t);

figure;
stairs(t_d,y_digital,'LineWidth',2)
grid on
title('Цифровая система (T1=1, T0=1)')
xlabel('t')
ylabel('y(t)')

info_digital = stepinfo(Wcl_digital);

fprintf('\nЦифровая система:\n')
fprintf('Время регулирования = %.4f\n',info_digital.SettlingTime)
fprintf('Перерегулирование = %.2f %%\n',info_digital.Overshoot)

%% 3. Эквивалентная модель
Tzap_values = [0.1*T0 0.4*T0 0.9*T0];

F = zeros(size(Tzap_values));

figure;

for i = 1:length(Tzap_values)

    Tzap = Tzap_values(i);
    
    Wfb = tf(1,[Tzap 1]);
    Wcl_equiv = feedback(Kp*Wo,Wfb);
    
    t_cont = 0:0.01:20;
    y_equiv = step(Wcl_equiv,t_cont);
    
    % Интерполяция цифрового сигнала
    y_d_interp = interp1(t_d,y_digital,t_cont,'previous','extrap');
    
    % Приведение к столбцам
    y_equiv = y_equiv(:);
    y_d_interp = y_d_interp(:);
    
    % Функционал F
    F(i) = trapz(t_cont,abs(y_d_interp - y_equiv));
    
    subplot(3,1,i)
    plot(t_cont,y_equiv,'LineWidth',2)
    grid on
    title(['Эквивалентная модель, Tзап = ',num2str(Tzap)])

end

%% 4. Построение зависимости F(Tзап)

figure;
plot(Tzap_values, F, 'o-','LineWidth',2)
grid on
xlabel('T_{зап}')
ylabel('F')
title('Зависимость функционала F от T_{зап}')

%% 5. Вывод результатов

fprintf('\nЗначения функционала F:\n')
for i = 1:length(Tzap_values)
    fprintf('Tзап = %.2f  ->  F = %.4f\n',Tzap_values(i),F(i))
end

[~, idx_min] = min(F);
fprintf('\nМинимум F достигается при:\n');
fprintf('Tзап = %.2f\n', Tzap_values(idx_min));