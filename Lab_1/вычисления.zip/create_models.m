clc;
clear;
close all;

Tu = 1;

models = {
    'Lin',  '1',              '[1 1 0]';      % 1/(s(s+1))
    'Bin',  '1',              '[1 2 1]';      % 1/(s+1)^2
    'Mod',  '1',              '[2 2 0]';      % 1/(2s(s+1))
    'Sym',  '1',              '[1 2 1 0]';    % 1/(s(s+1)^2)
    'Ast3', '1',              '[1 0 0 0]'     % 1/s^3
};

for i = 1:size(models,1)
    
    modelName = models{i,1};
    num = models{i,2};
    den = models{i,3};
    
    new_system(modelName);
    open_system(modelName);
    
    % Step
    add_block('simulink/Sources/Step', ...
        [modelName '/Step'], ...
        'Position',[30 100 60 130]);
    
    % Sum
    add_block('simulink/Math Operations/Sum', ...
        [modelName '/Sum'], ...
        'Inputs','+-', ...
        'Position',[100 100 130 130]);
    
    % Transfer Function
    add_block('simulink/Continuous/Transfer Fcn', ...
        [modelName '/TF'], ...
        'Numerator',num, ...
        'Denominator',den, ...
        'Position',[180 90 260 140]);
    
    % Scope
    add_block('simulink/Sinks/Scope', ...
        [modelName '/Scope'], ...
        'Position',[320 100 350 130]);
    
    % Lines
    add_line(modelName,'Step/1','Sum/1');
    add_line(modelName,'Sum/1','TF/1');
    add_line(modelName,'TF/1','Scope/1');
    add_line(modelName,'TF/1','Sum/2');
    
    save_system(modelName);
    
end

disp('Модели успешно созданы.');